package com.jtest;

public class Constants {
	public static String USER_DETAILS_FILE_PATH = "../applications/JTEST-0.0.1-SNAPSHOT/user_login_info.txt";
	public static String STUDENT_DETAILS_FILE_PATH = "../applications/JTEST-0.0.1-SNAPSHOT/student_marks.txt";
	public static String COMMA_EXPRESSION = ",";
	public static String FAILED_TO_LOGIN = "Either wrong username or password. Please retry.";
	public static int PASS_MARK = 40;
}
